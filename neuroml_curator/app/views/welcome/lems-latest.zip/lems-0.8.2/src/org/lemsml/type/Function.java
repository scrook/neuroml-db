package org.lemsml.type;

public class Function extends ComponentType {

	public LemsCollection<Argument> arguments;
	
}
