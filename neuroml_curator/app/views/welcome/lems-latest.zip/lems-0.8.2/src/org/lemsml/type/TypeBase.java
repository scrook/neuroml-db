package org.lemsml.type;

public class TypeBase {

}
