package org.lemsml.type;

import org.lemsml.util.ContentError;


public class Unit implements PseudoNamed, Summaried, DataMatchable {

    public static final String NO_UNIT = "none";

    private String name;
    public String symbol;
    public String dimension;
    private Dimension r_dimension;
    public int powTen = 0;
    public double scale = 1;
    public double offset = 0;

    public Unit() {
    }

    public Unit(String name, String symbol, Dimension dimension) {
        this.name = name;
        this.symbol = symbol;
        this.dimension = dimension.getName();
        this.r_dimension= dimension;
        this.powTen = 0;
        this.scale = 1;
    }

    public Unit(String name, String symbol, Dimension dimension, int powTen, double scale) {
        this.name = name;
        this.symbol = symbol;
        this.dimension = dimension.getName();
        this.r_dimension= dimension;
        this.powTen = powTen;
        this.scale = scale;
        this.offset = 0;
    }
    public Unit(String name, String symbol, Dimension dimension, int powTen, double scale, double offset) {
        this.name = name;
        this.symbol = symbol;
        this.dimension = dimension.getName();
        this.r_dimension= dimension;
        this.powTen = powTen;
        this.scale = scale;
        this.offset = offset;
    }

    public boolean dataMatches(Object obj) {
        boolean ret = false;
        if (obj instanceof Unit) {
            Unit u = (Unit) obj;
            if (symbol.equals(u.symbol) && powTen == u.powTen && dimension.equals(u.dimension)) {
                if (Math.abs(scale - u.scale) / (scale + u.scale) < 1.e-9) {
                    if (offset == 0 && u.offset==0) {
                        ret =true;
                    }
                    else if(Math.abs(offset - u.offset) / (offset + u.offset) < 1.e-9) {
                        ret = true;
                    }
                }
            }
        }
        return ret;
    }

    @Override
    public String toString() {
        return "Unit name=" + summary();
    }

    public String summary() {
        return name + ": " + symbol + ", dimension=" + dimension + ", scale=" + scale + ", powTen=" + powTen+", offset="+offset;
    }

    

    public void resolve(LemsCollection<Dimension> dimensions) throws ContentError {
        if (name == null) {
            name = symbol;
        }
        Dimension d = dimensions.getByName(dimension);
        if (d != null) {
            r_dimension = d;
            //	E.info("resolved unit " + name + " " + symbol);
        } else {
            throw new ContentError("no such dimension: " + dimension);
        }

    }

    public Dimension getDimension() {
        return r_dimension;
    }

    /*
    public double getMultiplier() {
        return scale * Math.pow(10, powTen);
    }*/

    public double convertFromUnitToSI(double val) {
        return ((val-offset) * scale * Math.pow(10, powTen));
    }

    public double convertFromSIToUnit(double siVal) {
        return offset + (siVal) / (scale * Math.pow(10, powTen));
    }


    public String getPseudoName() {
        return symbol;
    }

    public String getName() {
        return name;
    }

    public int getPowTen() {
        return powTen;
    }

    public double getScale() {
        return scale;
    }

    public String getSymbol() {
        return symbol;
    }


}
