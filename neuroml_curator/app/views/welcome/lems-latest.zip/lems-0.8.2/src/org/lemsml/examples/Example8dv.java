package org.lemsml.examples;
 

public class Example8dv {


	public static void main(String[] argv) {
		RunFileExample fe = new RunFileExample("example8dv.xml");
		fe.run();
	}
 
 
    
}
