package org.lemsml.type;

public interface IDd {

	
	public String getID();
	
	
	
}
