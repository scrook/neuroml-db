package org.lemsml.io;

public class FormatException extends Exception {
	private static final long serialVersionUID = 1L;

	
	public FormatException(String s) {
		super(s);
	}
}

