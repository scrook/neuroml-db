package org.lemsml.examples;
 
public class Example1cmdf {

	
 
		
		public static void main(String[] argv) {
			RunFileExample fe = new RunFileExample("cmdf/example1-cmdf.xml");
			fe.run();
		}
	    
		
		 
    
}
