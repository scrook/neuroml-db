package org.lemsml.comodl;

public class CM_Root {

}
