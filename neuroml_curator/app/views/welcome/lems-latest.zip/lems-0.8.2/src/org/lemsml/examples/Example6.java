package org.lemsml.examples;
 

public class Example6 {
	
	public static void main(String[] argv) {
		RunFileExample fe = new RunFileExample("example6.xml");
		fe.run();
	}

 
    
    
}
