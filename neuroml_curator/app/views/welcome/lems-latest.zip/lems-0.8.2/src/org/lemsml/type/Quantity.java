package org.lemsml.type;

public class Quantity {

	String text;
	
}
