package org.lemsml.type;

public interface Named {

	
	public String getName();
	
	
	
}
