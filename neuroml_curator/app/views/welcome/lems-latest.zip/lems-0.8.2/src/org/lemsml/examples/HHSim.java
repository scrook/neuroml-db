package org.lemsml.examples;


public class HHSim {

		public static void main(String[] argv) {
			RunFileExample fe = new RunFileExample("HH_Sim.xml");
			fe.run();
		}
	    
}
