package org.lemsml.selection;

import org.lemsml.expression.Node;

public class OpenPredicateNode extends Node {

	
	public String toString() {
		return "[";
	}
	
}
