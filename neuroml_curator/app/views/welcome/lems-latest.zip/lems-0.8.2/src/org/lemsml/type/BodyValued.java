package org.lemsml.type;


public interface BodyValued {

   
   public void setBodyValue(String s);

   public String getBodyValue();
  
   
}
