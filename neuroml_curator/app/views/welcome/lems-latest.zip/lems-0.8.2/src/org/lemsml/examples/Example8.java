package org.lemsml.examples;
 

public class Example8 {


	public static void main(String[] argv) {
		RunFileExample fe = new RunFileExample("example8.xml");
		fe.run();
	}
 
 
    
}
