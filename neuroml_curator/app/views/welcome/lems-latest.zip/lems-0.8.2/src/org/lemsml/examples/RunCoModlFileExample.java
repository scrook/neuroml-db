package org.lemsml.examples;

import java.io.File;

import org.lemsml.sim.Sim;
import org.lemsml.util.E;


public class RunCoModlFileExample {
 
	String filename;
	
	public RunCoModlFileExample(String fnm) {
		filename = fnm;
	}
	
		public void run() {
			File fex = new File("examples");
			File fs = new File(fex, filename);
			
			Sim sim = new Sim(fs);
	 
			try {
			// TODO one day this should be reading a pure file in the common format
			sim.readMixedModel(); 
		 		
			sim.build();
				
			sim.run();
			} catch (Exception ex) {
				ex.printStackTrace();
			}
			 
		}
	    
}
