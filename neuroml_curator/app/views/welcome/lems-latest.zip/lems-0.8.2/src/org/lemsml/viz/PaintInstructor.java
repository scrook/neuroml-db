package org.lemsml.viz;
 


public interface PaintInstructor {


     boolean antialias();

     void instruct(Painter p);
     
     Box getLimitBox();
   

}
