package org.lemsml.type;

public class Include {

    public String xmlns;
    public String file;

    public Include() {
    }

    public Include(String file) {
        this.file = file;
    }

	
}
