package org.lemsml.type;

public class Argument {

	public String name;
	
	public ReturnValue returnValue;
	
}
