package org.lemsml.examples;

import java.io.File;

import org.lemsml.sim.Sim;
import org.lemsml.util.E;


public class RunFileExample {
 
	String filename;
	
	public RunFileExample(String fnm) {
		filename = fnm;
	}
	
		public void run() {
			File fex = new File("examples");
			File fs = new File(fex, filename);
			
			Sim sim = new Sim(fs);
	 
			try {
			sim.readModel();	
		 		
			sim.build();
				
			sim.run();
			} catch (Exception ex) {
				ex.printStackTrace();
			}
			 
		}
	    
}
