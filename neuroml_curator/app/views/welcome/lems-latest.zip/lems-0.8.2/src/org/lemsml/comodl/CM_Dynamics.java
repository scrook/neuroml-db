package org.lemsml.comodl;

import org.lemsml.behavior.Behavior;
import org.lemsml.io.FormatException;
import org.lemsml.io.IOFace;
import org.lemsml.type.LemsCollection;
import org.lemsml.util.E;

public class CM_Dynamics implements IOFace {

	public LemsCollection<CM_StateVariable> cM_StateVariables = new LemsCollection<CM_StateVariable>();
	 
	
	public LemsCollection<CM_Alias> cM_Aliases = new LemsCollection<CM_Alias>();
	
	 
	public LemsCollection<CM_Regime> cM_Regimes = new LemsCollection<CM_Regime>();

	
	
 
	public Object getInternal() throws FormatException {
		return getBehavior();
	}
	
	
		
	public Behavior getBehavior() throws FormatException {	
		Behavior b = new Behavior();
		
		E.info("getting behavior - nregimes = " + cM_Regimes.size());
		
		for (CM_StateVariable cmsv : cM_StateVariables) {
			b.addStateVariable(cmsv.getStateVariable());
		}
	
		
		for (CM_Alias ali : cM_Aliases) {
			b.addDerivedVariable(ali.getDerivedVariable());
		}
		E.info("stripping regimes and putting in main");
		if (cM_Regimes.size() == 1) {
			CM_Regime cmr = cM_Regimes.first();
			for (CM_TimeDerivative td : cmr.cM_TimeDerivatives) {
				b.addTimeDerivative(td.getTimeDerivative());
			}
			for (CM_OnCondition oc : cmr.cM_OnConditions) {
				b.addOnCondition(oc.getOnCondition());
			}

			
		} else {
			E.info("Propagating regimes as is...");
			for (CM_Regime cmr : cM_Regimes) {
				b.addRegime(cmr.getRegime());				
			}
		}
		E.info("made behavior " + b.regimes.size());
		return b;
	}
	
	
	
	
	
}
