package org.lemsml.io;

import java.util.ArrayList;

import org.lemsml.util.ContentError;


public interface IOFace {

	public Object getInternal() throws FormatException, ContentError;
 
	
}
