package org.lemsml.annotation;

import java.util.ArrayList;

public interface ExplicitChildContainer {

	
	public ArrayList<Class<?>> getChildClasses();
	
}
