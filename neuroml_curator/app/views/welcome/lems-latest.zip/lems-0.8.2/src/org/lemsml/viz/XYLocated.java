package org.lemsml.viz;
 

public interface XYLocated {


     XYLocation getXYLocation();


}
