package org.lemsml.xml;


public interface XMLContainer {

	
	public void setXMLContent(String s);
	
	
}
