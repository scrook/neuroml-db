package org.lemsml.type;

import org.lemsml.annotation.Mat;
import org.lemsml.annotation.Mel;
import org.lemsml.util.ContentError;

@Mel(info="A constant quantity: like a parameter for which the value is supplied in the class definition itself rather " +
		"than when a component is defined.")
public class Constant implements Named  {
	@Mat(info="")
	public String name;
	
	@Mat(info="")
	public String value;
	@Mat(info="")
	public String dimension;
	public Dimension r_dimension;

    public Constant(){
        
    }

    public Constant(String name, Dimension dimension, String value) {
        this.name = name;
        this.dimension = dimension.getName();
        this.r_dimension = dimension;
        this.value = value;
    }

  
	public void resolve(LemsCollection<Dimension> dimensions) throws ContentError {
		Dimension d = dimensions.getByName(dimension);
		if (d != null) {
			r_dimension = d;
		//	E.info("resolved param " + name);
		} else {
			throw new ContentError("no such dimension: " + dimension);
		}
		
	}
	
	public String getValue() {
		return value;
	}
	
	public String getName() {
		return name;
	}

	public Dimension getDimension() {
		return r_dimension;
	}
	
}
