package org.lemsml.examples;
 
public class Izhklevichcmdf {

	
 
		
		public static void main(String[] argv) {
			RunCoModlFileExample fe = new RunCoModlFileExample("cmdf/izhikevich.xml");
			fe.run();
		}
	    
		
		 
    
}
