package org.lemsml.type;

public interface PseudoNamed {

	
	public String getPseudoName();
	
	
	
}
