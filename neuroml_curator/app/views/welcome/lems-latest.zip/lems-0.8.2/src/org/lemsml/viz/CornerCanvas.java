

package org.lemsml.viz;




public class CornerCanvas extends BaseCanvas {
   static final long serialVersionUID = 1001;

   public CornerCanvas(int w, int h) {
      super(w, h);
   }





}
