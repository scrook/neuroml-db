package org.lemsml.examples;
 

public class Example2 {
	
	public static void main(String[] argv) {
		RunFileExample fe = new RunFileExample("example2.xml");
		fe.run();
	}
	 
    
    
}
