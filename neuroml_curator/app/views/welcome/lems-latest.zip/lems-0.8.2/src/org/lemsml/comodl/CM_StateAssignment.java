package org.lemsml.comodl;

import org.lemsml.behavior.StateAssignment;
import org.lemsml.io.FormatException;
import org.lemsml.io.IOFace;

public class CM_StateAssignment  {

	public String variable;
	public CM_MathInline mathInline;

 
	
	public StateAssignment getStateAssignment() throws FormatException {	
		StateAssignment sa = new StateAssignment(variable);
		if (mathInline != null) {
			sa.value = mathInline.getFortranFormatBodyValue();
		} else {
			throw new FormatException("No math inline elemnt in " + this);
		}
		
		return sa;
	}
	 

  
}
