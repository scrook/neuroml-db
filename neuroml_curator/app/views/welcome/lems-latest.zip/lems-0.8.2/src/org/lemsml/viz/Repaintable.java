package org.lemsml.viz;


public interface Repaintable {


     void requestRepaint();

   void setCursor(String string);

}
