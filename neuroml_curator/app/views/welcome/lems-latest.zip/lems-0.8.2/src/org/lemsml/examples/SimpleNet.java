package org.lemsml.examples;
 

public class SimpleNet {


	public static void main(String[] argv) {
		RunFileExample fe = new RunFileExample("simple_net.xml");
		fe.run();
	}
 
 
    
}
