package org.lemsml.expression;

public class OpenNode extends Node {

	
	public String toString() {
		return "(";
	}
	
}
