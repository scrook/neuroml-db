package org.lemsml.io;

import org.lemsml.behavior.Behavior;
import org.lemsml.behavior.DerivedVariable;
import org.lemsml.behavior.OnCondition;
import org.lemsml.behavior.StateAssignment;
import org.lemsml.behavior.StateVariable;
import org.lemsml.behavior.TimeDerivative;
import org.lemsml.type.ComponentType;
import org.lemsml.type.EventPort;
import org.lemsml.type.Exposure;

public class CMDFMap extends NameMapper {
	
	// addElementRename("ComponentClass", "ComponentType");
		
	public CMDFMap() {
		addGlobalAttributeRename("class", "type");
	 
		addExportElementRename(ComponentType.class, "ComponentClass");
		addExportElementRename(Behavior.class, "Dynamics");
		addExportElementRename(Exposure.class, "AnalogPort");
		addExportAutoAttribute(Exposure.class, "mode", "send");
		addExportElementRename(DerivedVariable.class, "Alias");
		
		addExportAttributeRename(EventPort.class, "direction", "mode");
		
		addExportAttributeValueMapping(EventPort.class, "mode", "out", "send");
		
		addExportSuppressAttribute(Behavior.class, "consolidate");
		addExportSuppressAttribute(StateVariable.class, "exposure");
		addExportSuppressAttribute(DerivedVariable.class, "exposure");
		addExportSuppressAttribute(TimeDerivative.class, "exposure");
		
		addExportPushDown(TimeDerivative.class, "Regime");
		addExportPushDown(OnCondition.class, "Regime");
		
		addAttributeToElementMap(TimeDerivative.class, "value", "MathInline");
		addAttributeToElementMap(DerivedVariable.class, "value", "MathInline");
		addAttributeToElementMap(StateAssignment.class, "value", "MathInline");
		
		addAttributeToElementMap(OnCondition.class, "test", "Trigger/MathInline");
	}

	
 
}
