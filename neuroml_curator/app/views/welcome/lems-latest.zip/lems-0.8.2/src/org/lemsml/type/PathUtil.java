package org.lemsml.type;

import org.lemsml.util.ContentError;


// TMP - just place to keep these methods for now
public class PathUtil {

	
}
