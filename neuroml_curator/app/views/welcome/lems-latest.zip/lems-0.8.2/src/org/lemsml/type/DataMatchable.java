package org.lemsml.type;

public interface DataMatchable {

	public boolean dataMatches(Object obj);
	
}
