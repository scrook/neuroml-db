package org.lemsml.viz;


public interface BuildPaintMaster extends BuildPaintInstructor {


     void setSubject(Object obj);

}
