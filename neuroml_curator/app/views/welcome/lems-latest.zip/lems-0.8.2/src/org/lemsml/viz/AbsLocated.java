package org.lemsml.viz;
 

public interface AbsLocated {


     Position getAbsolutePosition();


}
