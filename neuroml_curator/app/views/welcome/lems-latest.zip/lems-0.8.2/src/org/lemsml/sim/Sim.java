package org.lemsml.sim;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import org.lemsml.behavior.Behavior;
import org.lemsml.canonical.CanonicalWriter;
import org.lemsml.comodl.CM_Root;
import org.lemsml.expression.ParseError;
import org.lemsml.io.CMDFMap;
import org.lemsml.io.LemsMap;
import org.lemsml.io.NameMapper;
import org.lemsml.run.ComponentBehavior;
import org.lemsml.run.ConnectionError;
import org.lemsml.run.EventManager;
import org.lemsml.run.RunConfig;
import org.lemsml.run.RunDisplay;
import org.lemsml.run.StateInstance;
import org.lemsml.type.Component;
import org.lemsml.type.DefaultRun;
import org.lemsml.type.Lems;
import org.lemsml.type.TypeBase;
import org.lemsml.util.ContentError;
import org.lemsml.util.E;
import org.lemsml.util.FileUtil;
import org.lemsml.util.RuntimeError;
import org.lemsml.viz.StandaloneViewer;
import org.lemsml.xml.ReflectionInstantiator;
import org.lemsml.xml.XMLReader;


public class Sim {

    // disable display output
    private static boolean disableFrames = false;

    private Class<?> root;
    private String srcfnm;
    private File srcFile;
    private String srcStr;
    
    private Lems lems;
    
    private ComponentBehavior rootBehavior;
    private RunConfig runConfig;
    private RunDisplay runDisplay;
    private StateInstance rootState;
    
    public final static int NONE = 0;
    public final static int PATH = 1;
    public final static int FILE = 2;
    public final static int STRING = 3;
    public final static int BUILT = 4;  // Built Lems object with aPI
    
    private int mode = NONE;
    
    
    File reportFile = null;
    File timesFile = null;

    
    
    
    public Sim(Class<?> c, String fnm) {
        root = c;
        srcfnm = fnm;
        mode = PATH;
    }

    public Sim(File file) {
        srcFile = file;
        mode = FILE;
    }

    public Sim(String srcStr) {
        this.srcStr = srcStr;
        mode = STRING;
    }

    public Sim(Lems lems) {
        this.lems = lems;
        mode = BUILT;
    }

    public static boolean isDisableFrames() {
        return disableFrames;
    }

    public static void setDisableFrames(boolean df) {
        disableFrames = df;
    }



    public void readModel() throws ContentError {
    	ReflectionInstantiator ri = new ReflectionInstantiator();
    	ri.addSearchPackage(TypeBase.class.getPackage());
    	ri.addSearchPackage(Behavior.class.getPackage());
    	
    	NameMapper cm = new LemsMap();
    	ri.setImportNameMapper(cm);
    	readModel(ri, false);
    	 
    }
    
    public void readMixedModel() throws ContentError {
    	ReflectionInstantiator ri = new ReflectionInstantiator();

    	ri.addSearchPackage(CM_Root.class.getPackage(), "CM_");

    	ri.addSearchPackage(TypeBase.class.getPackage());
    	ri.addSearchPackage(Behavior.class.getPackage());
    
    	NameMapper cm = new CMDFMap();
    	ri.setImportNameMapper(cm);
    	
    	readModel(ri, true);
    }
    	
    	
    public void readModel(ReflectionInstantiator refin, boolean loose) throws ContentError {
        String stxt = "";

        if (mode == FILE) {
            E.info("Reading model from " + srcFile.getAbsolutePath());

            FileInclusionReader fir = new FileInclusionReader(srcFile);
            stxt = fir.read();
            
        } else if (mode == PATH) {
            PathInclusionReader pir = new PathInclusionReader(root, srcfnm);
            stxt = pir.read();
        
        } else if (mode == STRING) {
            stxt = srcStr.trim();

            if (stxt.startsWith("<?xml")) {
                int index = stxt.indexOf(">");
                stxt = stxt.substring(index + 1).trim();
            }
            
            // TODO - not part of lems
            if (stxt.startsWith("<neuroml")) {
            	E.error("Using neuroml specific code in lems");
            	int index = stxt.indexOf(">");
                stxt = stxt.substring(index + 1);
                // Assume </neuroml> at end...
                stxt = stxt.replace("</neuroml>", "");

                stxt = "<Lems>\n\n"
                        + "    <Include file=\"NeuroML2CoreTypes/NeuroMLCoreDimensions.xml\"/>\n"
                        + "    <Include file=\"NeuroML2CoreTypes/Cells.xml\"/>\n"
                        + "    <Include file=\"NeuroML2CoreTypes/Networks.xml\"/>\n"
                        + "    <Include file=\"NeuroML2CoreTypes/Simulation.xml\"/>\n\n"
                        + stxt + "\n"
                        + "</Lems>";

            }
            StringInclusionReader sir = new StringInclusionReader(stxt);
            stxt = sir.read();
            /*
             */
        }
  
       

        XMLReader xmlr = new XMLReader(refin);


        try {
            lems = (Lems) (xmlr.read(stxt));

            if (loose) {
            	lems.setResolveModeLoose();
            }
            
            lems.deduplicate();
            lems.resolve();
            lems.evaluateStatic();
            
            
            

        } catch (Exception ex) {
        	ex.printStackTrace();
        }          


    }

    public void print() {
        E.info("Model:\n" + lems.textSummary());
    }

    public void build() throws ContentError, ConnectionError, ParseError {

        DefaultRun dr = lems.getDefaultRun();

        Component simCpt = dr.getComponent();

        if (simCpt == null) {
            E.error("No such component: " + dr.component + " as referred to by default simulation.");
            E.error(lems.textSummary());
        }

        E.info("Simulation component: " + simCpt);

        rootBehavior = simCpt.getComponentBehavior();

        runConfig = rootBehavior.getRunConfig();

        Component runCpt = runConfig.getTarget();
        
        EventManager eventManager = new EventManager();
        rootState = lems.build(runCpt, eventManager);

        runDisplay = simCpt.getRunDisplay(rootState);

        if (srcFile != null && srcFile.getParentFile() != null) {
            runDisplay.setRootForData(srcFile.getParentFile());
        }
        
        
        
        if (dr.reportFile != null) {
        	reportFile = new File(dr.reportFile);
        }
        if (dr.timesFile != null) {
        	timesFile = new File(dr.timesFile);
        }
     
        
    }

    
    
    public void run() throws ConnectionError, ContentError, RuntimeError, IOException {
        run(true);
    }

    public void run(boolean showFrame) throws ConnectionError, ContentError, RuntimeError, IOException {

        runUserDefined(showFrame);

        E.info("Done!");
    }

    public void runUserDefined() throws ConnectionError, ContentError, RuntimeError, IOException {
        runUserDefined(true);
    }

    
    
    public void runUserDefined(boolean showFrame) throws ConnectionError, ContentError, RuntimeError, IOException {

        RunnableAccessor ra = new RunnableAccessor(rootState);

        runDisplay.connectRunnable(ra);

        StandaloneViewer sv = new StandaloneViewer(runDisplay.getMainWindow());

        double dt = runConfig.getTimestep();
        int nstep = (int) Math.round(runConfig.getRuntime() / dt);

        E.info("Running for " + nstep + " steps, with " + runDisplay.getDisplayItems().size() + " display items");

      

        StringBuilder info = new StringBuilder("#Report of running simulation with LEMS Interpreter\n");
        StringBuilder times = new StringBuilder();

        if (reportFile != null) {
            E.info("Simulation report will go in " + reportFile.getAbsolutePath());
        }

        long start = System.currentTimeMillis();
  
        double t = 0;
        
       
        rootState.initialize(null);  
        EventManager eventManager = rootState.getEventManager();
        
        for (int istep = 0; istep < nstep; istep++) {
        	if (istep > 0) {
        		eventManager.advance(t);
                rootState.advance(null, t, dt);
        	}

            if (runDisplay == null) {
                rootState.exportState("", t, sv);
            } else {
                runDisplay.appendState(t, sv);
            }
            times.append((float) (t * 1000)).append("\n");
            t += dt;
        }
        E.info("Finished " + nstep + " steps");

        
        long end = System.currentTimeMillis();
        info.append("RealSimulationTime=" + ((end - start) / 1000.0) + "\n");
        start = System.currentTimeMillis();



        if (showFrame && !disableFrames) {
            sv.show();
            sv.frameData();
        }

        try {
            boolean incTimes = (timesFile == null);
            runDisplay.saveAll(incTimes);

            end = System.currentTimeMillis();
            info.append("SimulationSaveTime=" + ((end - start) / 1000.0) + "\n");

            if (reportFile != null) {
                FileUtil.writeStringToFile(info.toString(), reportFile);
            }
            if (timesFile != null) {
                FileUtil.writeStringToFile(times.toString(), timesFile);
            }

            if (showFrame && !disableFrames) {
                runDisplay.plotAll();
            }

        } catch (IOException ex) {
            throw new RuntimeError("Problem saving traces to file", ex);
        }

    }

    
    
    
    
    public String canonicalText() {
        CanonicalWriter cw = new CanonicalWriter(lems);
        return cw.writeText();
    }

    public Lems getLems() {
        return lems;
    }
}
