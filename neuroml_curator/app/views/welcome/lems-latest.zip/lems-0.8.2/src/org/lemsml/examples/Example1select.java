package org.lemsml.examples;
 
public class Example1select {

	
 
		
		public static void main(String[] argv) {
			RunFileExample fe = new RunFileExample("example1_nacurrent.xml");
			fe.run();
		}
	    
		
		 
    
}
