package org.lemsml.examples;
 

public class Net1 {


	public static void main(String[] argv) {
		RunFileExample fe = new RunFileExample("net1.xml");
		fe.run();
	}
 
 
    
}
