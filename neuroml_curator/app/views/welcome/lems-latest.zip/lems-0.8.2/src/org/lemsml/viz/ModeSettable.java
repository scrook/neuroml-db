
package org.lemsml.viz;


public interface ModeSettable {

  
   void setMode(String domain, String mode);

   void setMode(String domain, boolean value);
   
}
