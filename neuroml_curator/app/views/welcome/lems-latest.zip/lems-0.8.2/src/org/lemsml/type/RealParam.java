package org.lemsml.type;

public class RealParam {

	public String name;
	
}
