package org.lemsml.comodl;

import org.lemsml.behavior.EventOut;
import org.lemsml.behavior.OnCondition;
import org.lemsml.behavior.StateAssignment;
import org.lemsml.io.FormatException;
import org.lemsml.io.IOFace;
import org.lemsml.type.LemsCollection;

public class CM_OnCondition  {

	public CM_Trigger trigger;
	
	public LemsCollection<CM_StateAssignment> cM_StateAssignments = new LemsCollection<CM_StateAssignment>();
	
	public LemsCollection<CM_EventOut> cM_EventOuts = new LemsCollection<CM_EventOut>();

	 
	
	public OnCondition getOnCondition() throws FormatException {	
		OnCondition oc = new OnCondition();
		oc.test = trigger.getExpression();
		 
		for (CM_StateAssignment cmsa : cM_StateAssignments) {
			oc.addStateAssignment(cmsa.getStateAssignment());
		}
		
		for (CM_EventOut eo : cM_EventOuts) {
			oc.addEventOut(eo.getEventOut());
		}
		
		return oc;
	}
	
	
	
	
	
}
