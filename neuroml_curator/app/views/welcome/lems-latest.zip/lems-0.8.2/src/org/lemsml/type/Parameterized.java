package org.lemsml.type;

import java.util.HashMap;

public interface Parameterized {

	HashMap<String, Double> getVariables();

}
