package org.lemsml.viz;


public interface RotationListener {

	public void rotationChanged();

}
