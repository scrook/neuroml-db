package org.lemsml.run;

public class RunnableUnit {

	int index;
	
	public RunnableUnit(int idx) {
		index = idx;
	}
}
