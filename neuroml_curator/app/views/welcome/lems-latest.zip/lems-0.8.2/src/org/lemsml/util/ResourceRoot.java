package org.lemsml.util;

public class ResourceRoot {

}
