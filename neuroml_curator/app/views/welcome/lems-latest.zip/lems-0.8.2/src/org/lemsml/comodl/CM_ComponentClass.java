package org.lemsml.comodl;

import java.util.ArrayList;

import org.lemsml.io.FormatException;
import org.lemsml.io.IOFace;
import org.lemsml.io.IOFaceMixed;
import org.lemsml.type.ComponentType;
import org.lemsml.type.LemsCollection;
import org.lemsml.util.ContentError;

public class CM_ComponentClass implements IOFaceMixed {

	public String name;
	
	public LemsCollection<CM_Parameter> cM_Parameters = new LemsCollection<CM_Parameter>();
	
	public LemsCollection<CM_AnalogPort> cM_AnalogPorts = new LemsCollection<CM_AnalogPort>();
	
	public LemsCollection<CM_EventPort> cM_EventPorts = new LemsCollection<CM_EventPort>();
	
	public LemsCollection<CM_Dynamics> cM_Dynamicses = new LemsCollection<CM_Dynamics>();

	// pending is to hold native elements that get loaded while we're loading 
	// the face element
	public ArrayList<Object> pending = new ArrayList<Object>();
	
 
	public Object getInternal() throws FormatException, ContentError {
		return getComponentType();	
	}
	
	public void addPending(Object ob) {
		pending.add(ob);
	}
	
	public ArrayList<Object> getPending() {
		return pending;
	}
	
	
	public ComponentType getComponentType() throws FormatException, ContentError {
		ComponentType ret = new ComponentType(name);
		
		for (CM_Parameter p : cM_Parameters) {
			ret.addParameter(p.getParameter());
		}
		
		for (CM_EventPort ep : cM_EventPorts) {
			ret.addEventPort(ep.getEventPort());
		}
		
		for (CM_Dynamics d : cM_Dynamicses) {
			ret.addBehavior(d.getBehavior());
		}
		
		// these come last as they may need to add some stuff to the behavior
		for (CM_AnalogPort ap : cM_AnalogPorts) {
			ap.applyToType(ret);
		}
		
		return ret;
		
	}
	
	
	
}
