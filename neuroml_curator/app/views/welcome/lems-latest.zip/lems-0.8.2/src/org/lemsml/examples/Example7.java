package org.lemsml.examples;
 

public class Example7 {

	public static void main(String[] argv) {
		RunFileExample fe = new RunFileExample("example7.xml");
		fe.run();
	}
 
    
    
}
