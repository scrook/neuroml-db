package org.lemsml.examples;
 
public class Example1 {

	
 
		
		public static void main(String[] argv) {
			RunFileExample fe = new RunFileExample("example1.xml");
			fe.run();
		}
	    
		
		 
    
}
