package org.lemsml.viz;



public interface IntActor {

     void intAction(int iact);

}
