package org.lemsml.run;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import org.lemsml.behavior.Behavior;
import org.lemsml.behavior.Record;
import org.lemsml.behavior.Show;
import org.lemsml.sim.RunnableAccessor;
import org.lemsml.type.Attribute;
import org.lemsml.type.Component;
import org.lemsml.util.ContentError;
import org.lemsml.util.E;
import org.lemsml.util.RuntimeError;
import org.lemsml.viz.StandaloneViewer;

public class RunDisplay {

    StateRunnable stateRunnable;
    ArrayList<DisplayItem> displayItems = new ArrayList<DisplayItem>();
    private String mainWindow;

    public RunDisplay(StateRunnable sr) {
        stateRunnable = sr;
    }

    @Override
    public String toString() {
        return "RunDisplay for " + stateRunnable.getID() + " with disp items: " + displayItems + ", win: " + mainWindow;
    }

    public void setMainWindow(String mainWindow) {
        this.mainWindow = mainWindow;
    }

    public String getMainWindow() {
        return mainWindow;
    }

    public void setRootForData(File rootForData) {
        E.info("Root for saving data: " + rootForData.getAbsolutePath());
        //this.rootForData = rootForData;
        for (DisplayItem dit : displayItems) {
            dit.setRootForData(rootForData);
        }
    }

    public void appendState(double t, StandaloneViewer sv) throws ContentError, RuntimeError {
        for (DisplayItem dit : displayItems) {
            dit.appendState(t, sv);
        }
    }

    public void saveAll(boolean incTimes) throws IOException {

        for (DisplayItem dit : displayItems) {
            dit.save(incTimes);
        }
    }

    public ArrayList<DisplayItem> getDisplayItems() {
        return displayItems;
    }

    public void plotAll() throws IOException {

        HashMap<String, StandaloneViewer> displays = new HashMap<String, StandaloneViewer>();

        ArrayList<Float> times = null;

        if (displayItems.size()>0 && displayItems.get(0).getDataFile()!=null){
            File timeFile = new File(displayItems.get(0).getDataFile().getParentFile(), "time.dat");
            if (timeFile.exists()){
                    times = new ArrayList<Float>();
                    BufferedReader reader = new BufferedReader(new FileReader(timeFile));
                    String line;
                    while ((line = reader.readLine()) != null) {
                        if (line.trim().length() > 0) {
                            float t = Float.parseFloat(line.trim());
                            times.add(t);
                        }
                    }
            }
        }

        for (DisplayItem dit : displayItems) {
            String dispWin = dit.getDisplayWindow();

            if (!dispWin.equals(getMainWindow())) {

                File dataFile = dit.getDataFile();
                if (dataFile != null) {
                    E.info("Plotting data from " + dataFile + " in " + dispWin);
                    if (!displays.containsKey(dispWin)) {
                        StandaloneViewer sv = new StandaloneViewer(dispWin);
                        displays.put(dispWin, sv);
                    }
                    StandaloneViewer sv = displays.get(dispWin);

                    BufferedReader reader = new BufferedReader(new FileReader(dataFile));
                    String line;
                    int count=0;
                    while ((line = reader.readLine()) != null) {
                        //System.out.println("line: "+line);
                        if (line.trim().length() > 0) {

                            float x, y;
                            if (times!=null){
                                x = times.get(count);
                                y = Float.parseFloat(line.trim());
                            } else {
                                x = Float.parseFloat(line.split("\\s")[0]);
                                y = Float.parseFloat(line.split("\\s")[1]);
                            }

                            String ref = dit.getInfo();

                            sv.addPoint(ref, x, y, dit.getColor());
                            count++;
                        }
                    }

                }
            }
        }

        for (StandaloneViewer sv : displays.values()) {
            sv.show();
            sv.frameData();
        }
    }

    public void addShow(Component cpt, Show show, String displayWindow) throws ContentError {
        addShow(cpt, show, 1.0, displayWindow);
    }

    public void addShow(Component cpt, Show show, double defscl, String displayWindow) throws ContentError {
        double dscale = defscl;
        if (show.scale != null) {
            dscale = cpt.getParamValue(show.scale).getDoubleValue();
        }
        if (cpt.hasChildrenAL(show.src)) {
            ArrayList<Component> alc = cpt.getChildrenAL(show.src);

            for (Component c : alc) {
                Behavior b = c.getComponentType().getBehavior();
                //System.out.println("c: "+c);

                Attribute attr = c.attributes.getByName("title");
                if (attr != null) {
                    displayWindow = attr.getValue();
                }

                if (b != null) {
                    for (Show sub : b.shows) {
                        addShow(c, sub, dscale, displayWindow);
                    }
                    for (Record r : b.records) {
                        addRecord(c, r, dscale, displayWindow);
                    }
                }
            }
        }
    }

    private void addRecord(Component c, Record r, double tscale, String displayWindow) throws ContentError {
        double yscale = c.getParamValue(r.scale).getDoubleValue();
        String color = c.getStringValue(r.color);
        String path = c.getStringValue(r.quantity);

        DisplayItem dit = new DisplayItem(c.getID(), path, tscale, yscale, color, displayWindow);

        if (c.hasAttribute(r.save))
        {
            String save = c.getStringValue(r.save);
            //E.info("Save val: ("+save+")");
            dit.setSave(save);
        }
     

        // TODO need reimplementing outside of the display structure: getStringValue should throw an exception
        // if the value isn't there, not ignore it silently
        // String save = c.getStringValue(r.save);
        // dit.setSave(save);
        
        displayItems.add(dit);

    }

    public void connectRunnable(RunnableAccessor ra) throws ConnectionError {
        for (DisplayItem dit : displayItems) {

            dit.connectRunnable(ra);
        }
    }
}
