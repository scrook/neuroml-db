package org.lemsml.comodl;

import org.lemsml.behavior.Regime;
import org.lemsml.io.FormatException;
import org.lemsml.io.IOFace;
import org.lemsml.type.LemsCollection;

public class CM_Regime implements IOFace {

	public String name;
	
	public LemsCollection<CM_TimeDerivative> cM_TimeDerivatives = new LemsCollection<CM_TimeDerivative>();
	
	public LemsCollection<CM_OnCondition> cM_OnConditions = new LemsCollection<CM_OnCondition>();

	@Override
	public Object getInternal() throws FormatException {
		return getRegime();
	}
	
	public Regime getRegime() throws FormatException {
		Regime ret = new Regime(name);
		for (CM_TimeDerivative td : cM_TimeDerivatives) {
			ret.addTimeDerivative(td.getTimeDerivative());
		}
		for (CM_OnCondition oc : cM_OnConditions) {
			ret.addOnCondition(oc.getOnCondition());
		}
		return ret;
	}
	
	 
}
