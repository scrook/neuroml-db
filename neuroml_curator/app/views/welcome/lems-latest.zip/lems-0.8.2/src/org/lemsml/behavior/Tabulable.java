package org.lemsml.behavior;

public class Tabulable {

	public String variable;
	public String increment;
	
	
}
