package org.lemsml.display;

public interface LineDisplay {

	public void addPoint(String line, double x, double y);
	
	public void addPoint(String line, double x, double y, String scol);

}
