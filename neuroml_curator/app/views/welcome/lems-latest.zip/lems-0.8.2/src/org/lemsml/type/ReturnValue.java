package org.lemsml.type;

public class ReturnValue {

	public String expression;
	
}
