package org.lemsml.run;
 

public abstract class ChildBuilder extends BuilderElement implements ChildInstantiator {

	 
	
	
}
