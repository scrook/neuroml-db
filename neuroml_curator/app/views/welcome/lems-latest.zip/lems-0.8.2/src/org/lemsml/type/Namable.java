package org.lemsml.type;

public interface Namable {

	public void setName(String s);
	
	public String getName();
	
}
