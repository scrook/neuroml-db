package org.lemsml.type;

public class Reference<T> {

 
	public String targetID;
	
	
	 
	
}
