package org.lemsml.type;

import org.lemsml.util.ContentError;



public interface MetaContainer {


	public void addMetaItem(MetaItem mi) throws ContentError;


}
