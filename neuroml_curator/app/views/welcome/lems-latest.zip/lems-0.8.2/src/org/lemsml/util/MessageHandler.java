package org.lemsml.util;


public interface MessageHandler {



	public void msg(MessageType type, String txt);


	public void msg(String txt);


}
