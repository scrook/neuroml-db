package org.lemsml.annotation;

import java.lang.annotation.*;


@Retention(RetentionPolicy.RUNTIME)
@Target( { ElementType.TYPE})
public @interface Mel {

	String info();
	
}

