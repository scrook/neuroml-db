package org.lemsml.type;

public interface NameValuePairOnly extends Named {


   String getName();
   
   String getValue(); 

   

}
