package org.lemsml.type;

import org.lemsml.xml.XMLElement;


public interface RawValued {

   
   public void addXMLElement(XMLElement xe);
   
   
}
