package org.lemsml.run;

public class RUN {

	
	public final static int EULER = 1;
	public final static int RK4 = 2;
	
	public static int method = EULER; 

	
}

