package org.lemsml.canonical;

import org.lemsml.type.Component;
import org.lemsml.type.ComponentType;
import org.lemsml.type.Dimension;
import org.lemsml.type.Lems;

public class CanonicalWriter {

	Lems lems;
	
	
	public CanonicalWriter(Lems l) {
		lems = l;
	}

	public String writeText() {
		
		CanonicalElement root = new CanonicalElement("Lems");
		
		for (Dimension d : lems.dimensions) {
			root.add(d.makeCanonical());
		}
		for (ComponentType t : lems.componentTypes) {
			root.add(t.makeCanonical());
		}
		for (Component c : lems.components) {
			root.add(c.makeCanonical());
		}
	
		return root.toXMLString();
	}

}
