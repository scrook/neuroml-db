package org.lemsml.type;

import org.lemsml.util.ContentError;


public interface AddableTo {

   public void add(Object obj) throws ContentError;
   
}
