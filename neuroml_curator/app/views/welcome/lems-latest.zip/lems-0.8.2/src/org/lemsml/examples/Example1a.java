package org.lemsml.examples;
 
public class Example1a {

	
 
		
		public static void main(String[] argv) {
			RunFileExample fe = new RunFileExample("example1a.xml");
			fe.run();
		}
	    
		
		 
    
}
