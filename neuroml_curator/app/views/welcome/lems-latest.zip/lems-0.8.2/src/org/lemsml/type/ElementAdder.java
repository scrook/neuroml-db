package org.lemsml.type;

public interface ElementAdder {
	
	public void addElement(Object obj);

}
