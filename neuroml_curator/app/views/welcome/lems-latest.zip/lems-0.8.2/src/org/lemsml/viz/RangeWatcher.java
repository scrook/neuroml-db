package org.lemsml.viz;


public interface RangeWatcher {

   void rangeChanged();
   
}
