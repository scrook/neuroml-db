package org.lemsml.examples;
 

public class Example3weightDelay {

	public static void main(String[] argv) {
		RunFileExample fe = new RunFileExample("example3weight.xml");
		fe.run();
	}

	 
    
    
}
