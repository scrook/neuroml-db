package org.lemsml.type;

public interface FillableFrom {

	public void fillFrom(Object elt);
	
}
