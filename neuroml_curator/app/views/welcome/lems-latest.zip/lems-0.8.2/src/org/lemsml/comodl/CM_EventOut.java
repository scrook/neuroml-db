package org.lemsml.comodl;

import org.lemsml.behavior.EventOut;
import org.lemsml.io.FormatException;
import org.lemsml.io.IOFace;

public class CM_EventOut   {

	public String port;

	 
	
	public EventOut getEventOut() {	
		EventOut eo = new EventOut();
		eo.port = port;
		return eo;
	}
	
	
	
	
}
