package org.lemsml.viz;

import java.net.URL;

import javax.swing.ImageIcon;


public class DImageIcon extends ImageIcon {
   private static final long serialVersionUID = 1L;

   
   
   public DImageIcon(URL imgURL) {
      super(imgURL);
   }

}
