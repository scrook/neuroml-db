package org.lemsml.type;

public class IntParam {

	public String name;
	
}
