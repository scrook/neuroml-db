package org.lemsml.viz;


public interface XYLocation {

   
   double getX();

   double getY();

}
