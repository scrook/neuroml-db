package org.lemsml.comodl;

// we don't implenent IOFace as the container does it all. 
public class CM_Trigger {

	
	public CM_MathInline mathInline;
	
	
	public String getExpression() {
		return mathInline.getFortranFormatBodyValue();
	}
	
	
}
