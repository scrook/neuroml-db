package org.lemsml.type;

public class Base {

	public String id;
	
	public String description;

        public String getDescription() {
                return description;
        }

        public void setDescription(String description) {
                this.description = description;
        }
	
}
