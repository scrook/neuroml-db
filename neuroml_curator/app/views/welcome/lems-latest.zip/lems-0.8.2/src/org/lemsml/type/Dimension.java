package org.lemsml.type;

import org.lemsml.canonical.CanonicalElement;
import org.lemsml.expression.Dimensional;
import org.lemsml.util.E;

public class Dimension implements Named, Summaried, DataMatchable, Dimensional {

    public static final String NO_DIMENSION = "none";

    public String name;
    public int m;  // Mass
    public int l;  // Length
    public int t;  // Time
    public int i;  // Current
    public int k;  // Temperature
    public int c;  // Amount of substance
    private double dval = Double.NaN; // bit messy, just for constant powers

    public final static Dimension TIME_DIMENSION = new Dimension("time", 0, 0, 1, 0);
    
    
    
    public Dimension() {
    }

    public Dimension(String sn) {
        name = sn;
    }

    public Dimension(String sn, int am, int al, int at, int ai) {
        name = sn;
        m = am;
        l = al;
        t = at;
        i = ai;
        k = 0;
        c = 0;
    }

    public Dimension(String sn, int am, int al, int at, int ai, int ak, int ac) {
        name = sn;
        m = am;
        l = al;
        t = at;
        i = ai;
        k = ak;
        c = ac;
    }

    public boolean dataMatches(Object obj) {
        boolean ret = false;
        if (obj instanceof Dimension) {
            Dimension d = (Dimension) obj;
            if (m == d.m && l == d.l && t == d.t && i == d.i && k == d.k && c == d.c) {
                ret = true;
            }
        }
        return ret;
    }

    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return "Dimension[" + summary()+"]";
    }

    public String summary() {
        return ((name!=null&&name.length()>0)?name:"-none-") + ":" + 
        	(m != 0 ? " m=" + m : "") + (l != 0 ? " l=" + l : "") + (t != 0 ? " t=" + t : "")
                + (i != 0 ? " i=" + i : "") + (k != 0 ? " k=" + k : "") + (c != 0 ? " c=" + c : "")+ 
                (m==0&&l==0&&t==0&&i==0&&k==0&&c== 0 ? " dimensionless" : "");
    }

   

    public boolean matches(Dimension d) {
        boolean ret = false;
        if (this.equals(d)) {
            ret = true;

        } else if (m == d.m && l == d.l && t == d.t && i == d.i && k == d.k && c == d.c) {
            ret = true;
        } else {
            ret = false;
        }
        return ret;
    }

    public Dimension getTimes(Dimensional d) {
        Dimension ret = new Dimension("");
        ret.m = m + d.getM();
        ret.l = l + d.getL();
        ret.t = t + d.getT();
        ret.i = i + d.getI();
        ret.k = k + d.getK();
        ret.c = c + d.getC();
        return ret;
    }

    public Dimensional getDivideBy(Dimensional d) {
        Dimension ret = new Dimension("");
        ret.m = m - d.getM();
        ret.l = l - d.getL();
        ret.t = t - d.getT();
        ret.i = i - d.getI();
        ret.k = k - d.getK();
        ret.c = c - d.getC();
        return ret;
    }

    public boolean isDimensionless() {
        boolean ret = false;
        if (m == 0 && l == 0 && t == 0 && i == 0 && k == 0 && c == 0) {
            ret = true;
        }
        return ret;
    }

    public int getI() {
        return i;
    }

    public int getL() {
        return l;
    }

    public int getM() {
        return m;
    }

    public int getT() {
        return t;
    }

    public int getK() {
        return k;
    }

    public int getC() {
        return c;
    }

    public void setC(int c) {
        this.c = c;
    }

    public void setI(int i) {
        this.i = i;
    }

    public void setK(int k) {
        this.k = k;
    }

    public void setL(int l) {
        this.l = l;
    }

    public void setM(int m) {
        this.m = m;
    }

    public void setT(int t) {
        this.t = t;
    }

    

    public boolean matches(Dimensional d) {
        boolean ret = false;
        if (m == d.getM() && l == d.getL() && t == d.getT() && i == d.getI() && k == d.getK() && c == d.getC()) {
            ret = true;
        }
        return ret;
    }

    public Dimensional power(double dbl) {
        Dimensional ret = null;
        if (dbl - Math.round(dbl) < 1.e-6) {
            int ifac = (int) (Math.round(dbl));
            ret = new Dimension("", ifac * m, ifac * l, ifac * t, ifac * i, ifac * k, ifac * c);

        } else {
            E.missing("Can't work with fractional dimensions yet");
        }
        return ret;
    }

    public boolean isAny() {
        return false;
    }

    public void setDoubleValue(double d) {
        dval = d;
    }

    public double getDoubleValue() {
        return dval;
    }

    public CanonicalElement makeCanonical() {
        CanonicalElement ce = new CanonicalElement("Dimension");
        ce.add(new CanonicalElement("name", name));
        if (m != 0) {
            ce.add(new CanonicalElement("mass", "" + m));
        }
        if (l != 0) {
            ce.add(new CanonicalElement("length", "" + l));
        }
        if (t != 0) {
            ce.add(new CanonicalElement("time", "" + t));
        }
        if (i != 0) {
            ce.add(new CanonicalElement("current", "" + i));
        }
        if (k != 0) {
            ce.add(new CanonicalElement("temperature", "" + i));
        }
        if (c != 0) {
            ce.add(new CanonicalElement("amount", "" + i));
        }
        return ce;
    }

    
    // TODO this should probably go somewhere else
    public String getSIUnit() {
        StringBuilder sb = new StringBuilder();

        //todo: improve support for known units!!
        if (m==1 && l==2&& t==-3 && i==-1) return "V";
        if (m==-1 && l==-2&& t==4 && i==2) return "F";
        if (m==-1 && l==-2&& t==3 && i==2) return "S";

        if (m == 1) {
            sb.append(" kg");
        } else if (m != 0) {
            sb.append(" kg^" + m);
        }

        if (l == 1) {
            sb.append(" m");
        } else if (l != 0) {
            sb.append(" m^" + l);
        }

        if (t == 1) {
            sb.append(" s");
        } else if (t != 0) {
            sb.append(" s^" + t);
        }

        if (i == 1) {
            sb.append(" A");
        } else if (i != 0) {
            sb.append(" A^" + i);
        }

        if (k == 1) {
            sb.append(" K");
        } else if (k != 0) {
            sb.append(" K^" + i);
        }

        if (c == 1) {
            sb.append(" mol");
        } else if (c != 0) {
            sb.append(" mol^" + i);
        }

        if (sb.length() == 0) {
            return "";
        }

        return sb.toString().trim();
    }
}
