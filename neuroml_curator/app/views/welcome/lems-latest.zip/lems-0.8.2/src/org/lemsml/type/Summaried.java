package org.lemsml.type;

public interface Summaried {

	public String summary();
	
}
