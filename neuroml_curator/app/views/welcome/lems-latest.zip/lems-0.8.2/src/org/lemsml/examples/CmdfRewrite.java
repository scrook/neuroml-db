package org.lemsml.examples;

import java.io.File;

import org.lemsml.io.CMDFMap;
import org.lemsml.io.NameMapper;
import org.lemsml.serial.XMLSerializer;
import org.lemsml.sim.Sim;
import org.lemsml.type.Lems;
import org.lemsml.util.ContentError;
import org.lemsml.util.E;
import org.lemsml.util.FileUtil;
 
public class CmdfRewrite {

	 
		public static void main(String[] argv) {
	 		File fex = new File("examples");
	 		File fcmdf = new File(fex, "cmdf");
			File fs = new File(fcmdf, "izhikevich-only.xml");
			
			Sim sim = new Sim(fs);
	 
			try {
				sim.readMixedModel();	
		 		
				Lems lems = sim.getLems();
			
				String sout1 = XMLSerializer.serialize(lems, new CMDFMap());	 
			
				File fdirout = new File("tmp");
				File saveFile1 = new File(fdirout, "CMDF-save1.xml");
				FileUtil.writeStringToFile(sout1, saveFile1);
				
				Sim sim2 = new Sim(saveFile1);
				sim2.readMixedModel();
				
				Lems lems2 = sim2.getLems();
				
				String sout2 = XMLSerializer.serialize(lems2, new CMDFMap());	 
		
				File saveFile2 = new File(fdirout, "CMDF-save2.xml");
				FileUtil.writeStringToFile(sout2, saveFile2);
				
				if (sout1.equals(sout2)) {
					E.info("Read and rewritten files are the same");
				} else {
				//	E.info("First time: " + sout1);
				//	E.info("Rewritten:" + sout2);
					
					throw new ContentError("File mismatch ");
				}
				
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		
		}
	    
		
		 
    
}
