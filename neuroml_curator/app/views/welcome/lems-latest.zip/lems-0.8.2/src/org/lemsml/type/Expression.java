package org.lemsml.type;

public class Expression {

	public String text;
	
}
