package org.lemsml.run;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import org.lemsml.sim.RunnableAccessor;
import org.lemsml.util.ContentError;
import org.lemsml.util.E;
import org.lemsml.util.RuntimeError;
import org.lemsml.viz.StandaloneViewer;

public class DisplayItem {

    String id;
    String path;
    double tscale;
    double yscale;
    String color;
    StateWrapper stateWrapper;
    String saveFile;
    File rootForData;
    //HashMap<Double, Double> data  = new HashMap<Double, Double>(); //TODO: get a better struct for holding this
    ArrayList<Double> xVals = new ArrayList<Double>();
    ArrayList<Double> yVals = new ArrayList<Double>();
    String displayWindow = null;

    public DisplayItem(String sid, String p, double tf, double yf, String col, String displayWindow) {
        id = sid;
        path = p;
        tscale = tf;
        yscale = yf;
        color = col;
        this.displayWindow = displayWindow;
    }

    @Override
    public String toString() {
        return "DisplayItem{id=" + id + ", path=" + path + ", tscale=" + tscale + ", yscale=" + yscale + ", color=" + color
                + ", saveFile=" + saveFile + ", rootForData=" + rootForData + ", displayWindow=" + displayWindow + '}';
    }



    public void setSave(String saveFile) {
        this.saveFile = saveFile;
    }

    public void setRootForData(File rootForData) {
        this.rootForData = rootForData;
    }

    public String getDisplayWindow() {
        return displayWindow;
    }

    public void setDisplayWindow(String displayWindow) {
        this.displayWindow = displayWindow;
    }

    public String getId() {
        return id;
    }

    public String getColor() {
        return color;
    }

    public double getTscale() {
        return tscale;
    }

    public double getYscale() {
        return yscale;
    }

    public String getInfo() {
        return "<b>" + getId() + ": " + path + "</b>, x scale: " + tscale + ", y scale: " + yscale;
    }

    public void connectRunnable(RunnableAccessor ra) throws ConnectionError {
        stateWrapper = ra.getStateWrapper(path);
        if (stateWrapper == null) {
            throw new ConnectionError("unable to access state variable: " + path);
        }
    }

    public void appendState(double ft, StandaloneViewer sv) throws ContentError, RuntimeError {

        double x = ft / tscale;
        double y = stateWrapper.getValue() / yscale;
        //E.info("Adding point: ("+x+", "+y+")");
        if (sv.getTitle().equals(displayWindow)) {
            sv.addPoint(getInfo(), x, y, color);
        }

        if (saveFile != null) {
            xVals.add(x);
            yVals.add(y);
        }

    }

    public File getDataFile() {
        if (saveFile == null) {
            return null;
        }
        if (saveFile.indexOf("/") >= 0 || saveFile.indexOf("\\") >= 0) {
            //saveFile = saveFile.replaceAll("", "");
            File f = new File(saveFile);
            E.info("Using file " + f.getAbsolutePath() + " (" + saveFile + ")");
            return f;
        }
        File dataFile = new File(rootForData, saveFile);
        return dataFile;
    }

    public void save(boolean incTime) throws IOException {

        if (saveFile == null) {
            return;
        }
        File dataFile = getDataFile();
        E.info("Saving " + id + " (" + path + ") to file " + dataFile.getCanonicalPath());

        BufferedWriter out = new BufferedWriter(new FileWriter(dataFile));

        for (int i = 0; i < xVals.size(); i++) {
            if (incTime) {
                out.write(xVals.get(i).floatValue() + "\t" + yVals.get(i).floatValue() + "\n");
            } else {
                out.write(yVals.get(i).floatValue() + "\n");
            }
        }
         out.close();

    }
}
