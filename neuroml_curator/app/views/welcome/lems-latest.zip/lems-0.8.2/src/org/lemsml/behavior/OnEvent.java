package org.lemsml.behavior;

import java.util.HashMap;

import org.lemsml.annotation.*;
import org.lemsml.expression.ParseError;
import org.lemsml.expression.Parser;
import org.lemsml.expression.Valued;
import org.lemsml.type.EventPort;
import org.lemsml.type.LemsCollection;
import org.lemsml.util.ContentError;



@Mel(info="Event handler block")
public class OnEvent extends PointResponse {
 
	@Mat(info="the port to lesten on")
	public String port;
	
	EventPort eventPort;
	  
	 
	public void resolve(Behavior bhv, LemsCollection<StateVariable> stateVariables, HashMap<String, Valued> valHM, Parser parser) throws ContentError, ParseError {
	
		eventPort = bhv.getComponentClass().getInEventPort(port);
	 
		supResolve(bhv, stateVariables, valHM, parser);
	}




	public String getPortName() {
		return eventPort.getName();
	}




	
}
