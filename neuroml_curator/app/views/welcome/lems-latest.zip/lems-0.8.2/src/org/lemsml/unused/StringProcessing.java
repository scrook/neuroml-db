package org.lemsml.unused;

import org.lemsml.util.E;

public class StringProcessing {
	
	
	// this is a bit messy: Sim lives outside the normal dimensions mechanism but we still want the option of 
	// having units (ms or s) on the runtime and timestep.
	private double readTime(String sr) {
		double ret = 0;
		String s = sr;
		if (s == null) {
			ret = Double.NaN;
		} else {
			try {
				double fac = 1.0;
				s = s.trim();
				
				if (s.endsWith("us")) {
					fac = 1.e-6;
					s = s.substring(0, s.length()-2);
					
				} else if (s.endsWith("ms")) {
					fac = 1.e-3;
					s = s.substring(0, s.length()-2);
					 
				} else if (s.endsWith("s")) {
					fac = 1.;
					s = s.substring(0, s.length()-1);
				} 
				ret = fac * Double.parseDouble(s);
				
			} catch (Exception ex) {
				E.error("Cant read time from : " + s);
			}
		}
		return ret;
	}


}
