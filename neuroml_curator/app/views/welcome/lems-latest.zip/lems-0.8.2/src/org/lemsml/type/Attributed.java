package org.lemsml.type;

public interface Attributed {

	public void addAttribute(Attribute att);
	
}
