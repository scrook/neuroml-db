package org.lemsml.io;

public class LemsMap extends NameMapper {
	 
		
	public LemsMap() {
		addGlobalAttributeRename("class", "type");
		addGlobalAttributeRename("compClass", "type");
		addGlobalAttributeRename("extends", "eXtends");

        addInputElementRename("ComponentClass", "ComponentType");
        addInputElementRename("Dynamics", "Behavior");
	}
}
