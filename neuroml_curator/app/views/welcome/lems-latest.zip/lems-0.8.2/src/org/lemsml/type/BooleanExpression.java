package org.lemsml.type;

public class BooleanExpression extends Expression {

 
}
