package org.lemsml.viz;


public interface ClickListener {

   
   void pointClicked(int x, int y, int button);
   
   
}
