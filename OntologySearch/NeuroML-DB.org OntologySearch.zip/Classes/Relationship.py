class Relationship:
    def __init__(self, subject, relationship, object):
        self.Subject = subject
        self.Relationship = relationship
        self.Object = object