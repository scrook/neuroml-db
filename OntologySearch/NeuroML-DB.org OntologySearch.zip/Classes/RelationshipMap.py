class RelationshipMap:

    def __init__(self):
        pass


    Forward = {
        "Located_in": "Located in",
        "Neurotransmitter": "Releases",
    }

    Backward = {
        "Located_in": "Includes",
        "Neurotransmitter": "Released by",
    }