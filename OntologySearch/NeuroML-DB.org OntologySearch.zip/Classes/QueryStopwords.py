"""Defines the list of words that should be removed from query"""
class QueryStopwords:
    words = [
        "neuron",
        "cell",
        # add others here

    ]