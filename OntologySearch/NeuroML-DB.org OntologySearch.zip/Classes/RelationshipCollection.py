class RelationshipCollection:
    def __init__(self):

        self.DirectRelationships = []
        self.GapRelationships = []